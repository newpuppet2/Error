module.exports = {
    googleClientID: '603837850777-m503hu9hu3ilnhvep92284uj0nqetmpm.apps.googleusercontent.com',
    googleClientSecret: '7IHuaHhXU6zlJ5hxBz8ZSLzm',
    cookieKey: 'kjghkjshhklkjksjdfkjl',
    mongoURI: 'mongodb+srv://dbuser1:TkV8ZYhgAA6ftR6i@cluster0-emxmo.mongodb.net/test?retryWrites=true&w=majority'
    };