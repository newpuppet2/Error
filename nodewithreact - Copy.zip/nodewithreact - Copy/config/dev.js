module.exports = {
    googleClientID: '603837850777-m503hu9hu3ilnhvep92284uj0nqetmpm.apps.googleusercontent.com',
    googleClientSecret: '7IHuaHhXU6zlJ5hxBz8ZSLzm',
    cookieKey: 'kjghkjshhklkjksjdfkjl',
    mongoURI: 'mongodb+srv://dbuser1:TkV8ZYhgAA6ftR6i@cluster0-emxmo.mongodb.net/test?retryWrites=true&w=majority',
    stripePublishableKey: 'pk_test_dKZxavK0k1eMgsN9MFM9oPBh',
    stripeSecretKey: 'sk_test_lk5uTbIQEef2AQUv9I5s5KTs',
    sendGridKey: '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'
    };