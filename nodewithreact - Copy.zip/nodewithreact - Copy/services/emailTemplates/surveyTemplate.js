module.exports = survey => {
   return '<div>' + survey.body + '</div>';

};