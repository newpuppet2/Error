import React from 'react';

const Landing = () => {
    return (
       <div style={{ textAlign: 'center'}}>

         <h1>
             Emaily!
          </h1>   
          collect feedback from users
        </div>
    );
};

export default Landing;